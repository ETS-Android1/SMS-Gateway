package com.example.smsclientapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import com.example.smsclientapp.R;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.view.Gravity;
import  android.view.ViewGroup.LayoutParams.*;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Logger;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import java.io.InputStream;
import java.net.*;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText pn ;
    EditText msg;
    Button send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         pn = (EditText) findViewById(R.id.textPhone);
         msg = (EditText) findViewById(R.id.msg);
         send = (Button) findViewById(R.id.send);

        send.setBackgroundColor(Color.rgb(235,235,235));
        send.setTextColor(Color.BLACK);

        pn.setTextColor(Color.BLACK);
        pn.setBackgroundColor(Color.rgb(235,235,235));
        pn.setHintTextColor(Color.rgb(50,50,50));

        msg.setBackgroundColor(Color.rgb(235,235,235));
        msg.setHintTextColor(Color.rgb(50,50,50));
        msg.setTextColor(Color.BLACK);
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  TODO

                new APIHandler().execute("http://10.0.2.2:3000/sendSMS");


            }
        });
    }
    //#########################################
    private  class APIHandler extends AsyncTask<String,String,String>{

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                connection.setRequestProperty("Accept","application/json");
                connection.connect();

                // JSONObject to send
                JSONObject dataTosend = new JSONObject();
                dataTosend.put("phone", pn.getText().toString());
                dataTosend.put("MsgBody", msg.getText().toString());


                DataOutputStream os = new DataOutputStream(connection.getOutputStream());
                os.writeBytes(dataTosend.toString());
                os.flush();
                os.close();

                Log.d("Status", String.valueOf(connection.getResponseCode()));
                Log.d("ResponseBody", connection.getResponseMessage());


                connection.disconnect();
               return null;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                Log.d("HERE", "doInBackground: Inside Exception ");
                e.printStackTrace();
            }catch (org.json.JSONException e){

            }
            finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Toast.makeText(getApplicationContext(), "Message Sent!", Toast.LENGTH_SHORT).show();
        }
    }

    }


